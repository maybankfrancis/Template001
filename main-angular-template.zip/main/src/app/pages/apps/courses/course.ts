// tslint:disable-next-line: class-name
export class course {
  Id = -1;
  courseType = '';
  courseFramework = '';
  Time = '';
  courseName = '';
  Update = '';
}
